import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { insertRacketSchema, type InsertRacket, type Racket } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const form = useForm<InsertRacket>({
    resolver: zodResolver(insertRacketSchema),
    defaultValues: {
      brand: "",
      model: "",
      serialNumber: "",
      owner: "",
      userId: user?.id,
    },
  });

  const { data: rackets = [], isLoading: isLoadingRackets } = useQuery<Racket[]>({
    queryKey: ["/api/rackets", searchQuery],
    queryFn: () => fetch(`/api/rackets${searchQuery ? `?q=${searchQuery}` : ""}`).then(r => r.json()),
    enabled: !!user,
  });

  const createRacket = useMutation({
    mutationFn: async (data: InsertRacket) => {
      const res = await apiRequest("POST", "/api/rackets", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rackets"] });
      form.reset();
      toast({
        title: "Success",
        description: "QR code generated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate QR code",
        variant: "destructive",
      });
    },
  });

  if (user) {
    setLocation("/dashboard");
    return null;
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Hero Section */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold tracking-tight">Tennis Racket QR Code Manager</h1>
          <p className="text-xl text-muted-foreground">
            Generate and manage QR codes for your tennis rackets. Keep track of specifications and maintenance history.
          </p>
          <div className="flex justify-center gap-4">
            <Button onClick={() => setLocation("/register")} size="lg">
              Get Started
            </Button>
            <Button onClick={() => setLocation("/login")} variant="outline" size="lg">
              Sign In
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid gap-8 md:grid-cols-3">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-semibold mb-2">Easy QR Generation</h3>
              <p className="text-muted-foreground">
                Generate QR codes for your rackets in seconds. Store all important details securely.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-semibold mb-2">Track Your Collection</h3>
              <p className="text-muted-foreground">
                Keep track of your entire racket collection. Search and manage them easily.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-semibold mb-2">Share & Access</h3>
              <p className="text-muted-foreground">
                Share racket details with stringers or fellow players through QR codes.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}