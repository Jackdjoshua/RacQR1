import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Search, Plus } from "lucide-react";
import { insertRacketSchema, type InsertRacket, type Racket } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";

export default function Collection() {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const form = useForm<InsertRacket>({
    resolver: zodResolver(insertRacketSchema),
    defaultValues: {
      brand: "",
      model: "",
      serialNumber: "",
      owner: "",
      userId: user?.id,
      stringTension: undefined,
      mainStrings: "",
      crossStrings: "",
    },
  });

  const { data: rackets = [], isLoading } = useQuery<Racket[]>({
    queryKey: ["/api/rackets", searchQuery],
    queryFn: () => 
      fetch(`/api/rackets${searchQuery ? `?q=${searchQuery}` : ""}`, {
        credentials: 'include'
      })
        .then(r => {
          if (!r.ok) throw new Error('Failed to fetch rackets');
          return r.json();
        }),
    enabled: !!user,
  });

  const createRacket = useMutation({
    mutationFn: async (data: InsertRacket) => {
      const res = await apiRequest("POST", "/api/rackets", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rackets"] });
      form.reset();
      toast({
        title: "Success",
        description: "QR code generated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate QR code",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="grid gap-8 md:grid-cols-2">
          {/* Left column - Form */}
          <Card>
            <CardHeader>
              <CardTitle>Add New Racket</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit((data) => createRacket.mutate(data))} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="brand"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Brand</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter brand name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="model"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Model</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter model name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="serialNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Serial Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter serial number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="owner"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Owner Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter owner name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="stringTension"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>String Tension (lbs)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="Enter tension (30-70 lbs)" 
                            min={30} 
                            max={70}
                            {...field}
                            onChange={e => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="mainStrings"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Main Strings</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter main strings (e.g., RPM Blast 17)" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="crossStrings"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cross Strings</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter cross strings (e.g., Alu Power 16L)" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full" disabled={createRacket.isPending}>
                    {createRacket.isPending ? "Generating..." : "Generate QR Code"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Right column - Tennis racket image */}
          <div className="hidden md:block relative rounded-lg overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1544808208-727498b3df07"
              alt="Tennis Racket"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Search and Results */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Your Racket Collection</CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search rackets..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p>Loading your rackets...</p>
            ) : rackets.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No rackets found</p>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {rackets.map((racket) => (
                  <Card key={racket.id}>
                    <CardContent className="p-4">
                      <img
                        src={racket.qrCode}
                        alt={`QR Code for ${racket.brand} ${racket.model}`}
                        className="w-full mb-4"
                      />
                      <div className="space-y-1">
                        <p className="font-semibold">
                          {racket.brand} {racket.model}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          S/N: {racket.serialNumber}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Owner: {racket.owner}
                        </p>
                        {racket.stringTension && (
                          <p className="text-sm text-muted-foreground">
                            Tension: {racket.stringTension} lbs
                          </p>
                        )}
                        {racket.mainStrings && (
                          <p className="text-sm text-muted-foreground">
                            Mains: {racket.mainStrings}
                          </p>
                        )}
                        {racket.crossStrings && (
                          <p className="text-sm text-muted-foreground">
                            Crosses: {racket.crossStrings}
                          </p>
                        )}
                      </div>
                      <Button
                        variant="outline"
                        className="w-full mt-4"
                        onClick={() => {
                          const link = document.createElement('a');
                          link.href = racket.qrCode;
                          link.download = `qr-${racket.serialNumber}.png`;
                          link.click();
                        }}
                      >
                        Download QR Code
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}