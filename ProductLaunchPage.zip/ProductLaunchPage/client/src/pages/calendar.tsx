import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast"; // Corrected import path
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

type StringingAppointment = {
  id: number;
  date: string;
  racketId: number;
  notes: string;
};

export default function CalendarPage() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [notes, setNotes] = useState("");
  const [selectedRacketId, setSelectedRacketId] = useState<number | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: rackets = [] } = useQuery({
    queryKey: ["/api/rackets"],
    queryFn: () => apiRequest("GET", "/api/rackets").then(r => r.json()),
    enabled: !!user,
  });

  const { data: appointments = [] } = useQuery<StringingAppointment[]>({
    queryKey: ["/api/appointments"],
    queryFn: () => apiRequest("GET", "/api/appointments").then(r => r.json()),
    enabled: !!user,
  });

  const createAppointment = useMutation({
    mutationFn: async (data: Omit<StringingAppointment, "id">) => {
      const res = await apiRequest("POST", "/api/appointments", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      setNotes("");
      toast({
        title: "Success",
        description: "Appointment scheduled successfully",
      });
    },
  });

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>Schedule Stringing</CardTitle>
        </CardHeader>
        <CardContent className="flex gap-4">
          <div>
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md border"
            />
          </div>
          <div className="flex-1 space-y-4">
            <Select onValueChange={(value) => setSelectedRacketId(Number(value))}>
              <SelectTrigger>
                <SelectValue placeholder="Select a racket" />
              </SelectTrigger>
              <SelectContent>
                {rackets.map((racket: any) => (
                  <SelectItem key={racket.id} value={String(racket.id)}>
                    {racket.brand} {racket.model}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Textarea
              placeholder="Add notes..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
            <Button
              onClick={() => {
                if (!date || !selectedRacketId) return;
                createAppointment.mutate({
                  date: date.toISOString(),
                  racketId: selectedRacketId,
                  notes
                });
              }}
            >
              Schedule
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}