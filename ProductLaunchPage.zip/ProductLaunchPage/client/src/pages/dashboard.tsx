import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LogOut, Plus, QrCode, User, Home, Calendar } from "lucide-react";
import { useLocation } from "wouter";
import type { Racket } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  const { data: rackets = [], isLoading } = useQuery<Racket[]>({
    queryKey: ["/api/rackets"],
    queryFn: () => 
      fetch("/api/rackets", {
        credentials: 'include'
      })
        .then(r => {
          if (!r.ok) throw new Error('Failed to fetch rackets');
          return r.json();
        }),
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Welcome, {user?.name}</h1>
              <p className="text-muted-foreground">Manage your tennis racket collection</p>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" onClick={() => setLocation("/")}>
                <Home className="h-4 w-4 mr-2"/>
                Home
              </Button>
              <Button variant="ghost" onClick={() => setLocation("/calendar")}>
                <Calendar className="h-4 w-4 mr-2"/>
                Calendar
              </Button>
              <Button variant="ghost" onClick={() => logout()}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Profile Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <Avatar className="h-20 w-20">
                  {user?.profilePicture ? (
                    <AvatarImage src={user.profilePicture} alt={user?.name} />
                  ) : (
                    <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                  )}
                </Avatar>
                <div>
                  <h3 className="font-medium">{user?.name}</h3>
                  <p className="text-sm text-muted-foreground">{user?.email}</p>
                </div>
              </div>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setLocation("/settings")}
              >
                <User className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            </CardContent>
          </Card>
          <Card className="relative overflow-hidden">
            <CardHeader>
              <CardTitle>Manage Collection</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4 text-muted-foreground">
                Add, view, and manage your tennis racket collection. Generate QR codes for easy tracking.
              </p>
              <Button onClick={() => setLocation("/collection")}>
                <QrCode className="h-4 w-4 mr-2" />
                View Collection
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p className="text-lg font-semibold">{rackets.length} Rackets</p>
                <p className="text-muted-foreground">in your collection</p>
              </div>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setLocation("/collection")}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add New Racket
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}