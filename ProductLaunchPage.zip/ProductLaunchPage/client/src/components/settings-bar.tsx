
import React from "react"
import { Button } from "./ui/button"
import { Settings, User } from "lucide-react"
import { useLocation } from "wouter"
import {
  SidebarGroup,
  SidebarMenu,
  SidebarHeader,
  SidebarContent,
  Sidebar,
} from "./ui/sidebar"

export function SettingsBar() {
  const [, setLocation] = useLocation()

  return (
    <Sidebar side="right" variant="floating" collapsible="icon">
      <SidebarContent>
        <SidebarHeader>
          <h2 className="px-2 text-lg font-semibold tracking-tight">
            Settings
          </h2>
        </SidebarHeader>
        <SidebarGroup>
          <SidebarMenu>
            <Button 
              variant="ghost" 
              className="w-full justify-start"
              onClick={() => setLocation("/settings")}
            >
              <User className="mr-2 h-4 w-4" />
              Profile Settings
            </Button>
            <Button 
              variant="ghost" 
              className="w-full justify-start"
              onClick={() => setLocation("/app-settings")}
            >
              <Settings className="mr-2 h-4 w-4" />
              App Settings
            </Button>
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  )
}
