import { rackets, users, type User, type Racket, type InsertUser, type InsertRacket } from "@shared/schema";
import bcrypt from "bcryptjs";

export interface IStorage {
  // User operations
  createUser(user: InsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserById(id: number): Promise<User | undefined>;
  updateUser(id: number, user: Partial<User>): Promise<User>;

  // Racket operations
  createRacket(racket: InsertRacket & { qrCode: string, userId: number }): Promise<Racket>;
  getRacket(id: number): Promise<Racket | undefined>;
  getUserRackets(userId: number): Promise<Racket[]>;
  searchRackets(query: string, userId: number): Promise<Racket[]>;
  getAllRackets(): Promise<Racket[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private rackets: Map<number, Racket>;
  private currentUserId: number;
  private currentRacketId: number;

  constructor() {
    this.users = new Map();
    this.rackets = new Map();
    this.currentUserId = 1;
    this.currentRacketId = 1;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const user: User = {
      id,
      ...userData,
      password: hashedPassword,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async getUserById(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }

    const updatedUser = {
      ...user,
      ...userData,
      id,
      password: user.password, // Don't update password through this method
    };

    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async createRacket(racket: InsertRacket & { qrCode: string; userId: number }): Promise<Racket> {
    const id = this.currentRacketId++;
    const newRacket: Racket = {
      ...racket,
      id,
      createdAt: new Date(),
    };
    this.rackets.set(id, newRacket);
    return newRacket;
  }

  async getRacket(id: number): Promise<Racket | undefined> {
    return this.rackets.get(id);
  }

  async getUserRackets(userId: number): Promise<Racket[]> {
    return Array.from(this.rackets.values()).filter(
      (racket) => racket.userId === userId
    );
  }

  async searchRackets(query: string, userId: number): Promise<Racket[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.rackets.values()).filter(
      (racket) =>
        racket.userId === userId &&
        (racket.brand.toLowerCase().includes(lowercaseQuery) ||
          racket.model.toLowerCase().includes(lowercaseQuery) ||
          racket.serialNumber.toLowerCase().includes(lowercaseQuery) ||
          racket.owner.toLowerCase().includes(lowercaseQuery))
    );
  }

  async getAllRackets(): Promise<Racket[]> {
    return Array.from(this.rackets.values());
  }

  private appointments = new Map<number, Appointment>();
  private appointmentCounter = 1;

  async createAppointment(data: InsertAppointment & { userId: number }): Promise<Appointment> {
    const appointment = {
      id: this.appointmentCounter++,
      ...data,
      createdAt: new Date(),
    };
    this.appointments.set(appointment.id, appointment);
    return appointment;
  }

  async getUserAppointments(userId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.userId === userId
    );
  }
}

export const storage = new MemStorage();