import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertRacketSchema, insertUserSchema } from "@shared/schema";
import QRCode from "qrcode";
import bcrypt from "bcryptjs";
import session from "express-session";
import { z } from "zod";

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

// Auth middleware - moved to the top
const requireAuth = (req: any, res: any, next: any) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
};

export async function registerRoutes(app: Express) {
  // Session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "your-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        sameSite: "lax",
        path: "/",
      },
    })
  );

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(userData.email);

      if (existingUser) {
        return res.status(400).json({ error: "Email already registered" });
      }

      const hashedPassword = await bcrypt.hash(userData.password, 10);
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      req.session.userId = user.id;

      res.json({
        id: user.id,
        email: user.email,
        name: user.name,
      });
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      const user = await storage.getUserByEmail(email);

      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      req.session.userId = user.id;
      res.json({
        id: user.id,
        email: user.email,
        name: user.name,
      });
    } catch (error) {
      res.status(400).json({ error: "Invalid login data" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    try {
      const user = await storage.getUserById(req.session.userId);
      if (!user) {
        return res.status(401).json({ error: "User not found" });
      }
      res.json({
        id: user.id,
        email: user.email,
        name: user.name,
        phone: user.phone,
        profilePicture: user.profilePicture,
      });
    } catch (error) {
      res.status(500).json({ error: "Server error" });
    }
  });

  app.patch("/api/auth/profile", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUserById(userId);

      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const updatedUser = await storage.updateUser(userId, {
        name: req.body.name || user.name,
        email: req.body.email || user.email,
        phone: req.body.phone,
        profilePicture: req.body.profilePicture,
      });

      res.json({
        id: updatedUser.id,
        email: updatedUser.email,
        name: updatedUser.name,
        phone: updatedUser.phone,
        profilePicture: updatedUser.profilePicture,
      });
    } catch (error) {
      res.status(400).json({ error: "Failed to update profile" });
    }
  });

  // Racket routes
  app.post("/api/rackets", requireAuth, async (req, res) => {
    try {
      const racketData = insertRacketSchema.parse(req.body);
      const qrData = JSON.stringify({
        ...racketData,
        userId: req.session.userId,
        timestamp: new Date().toISOString(),
      });

      const qrCode = await QRCode.toDataURL(qrData);
      const racket = await storage.createRacket({
        ...racketData,
        qrCode,
        userId: req.session.userId!,
      });

      res.json(racket);
    } catch (error) {
      res.status(400).json({ error: "Invalid racket data" });
    }
  });

  app.get("/api/rackets", requireAuth, async (req, res) => {
    const query = req.query.q as string;
    const rackets = query
      ? await storage.searchRackets(query, req.session.userId!)
      : await storage.getUserRackets(req.session.userId!);
    res.json(rackets);
  });

  app.get("/api/rackets/:id", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    const racket = await storage.getRacket(id);

    if (!racket || racket.userId !== req.session.userId) {
      res.status(404).json({ error: "Racket not found" });
      return;
    }

    res.json(racket);
  });

  // Appointment routes
  app.post("/api/appointments", requireAuth, async (req, res) => {
    try {
      const appointmentData = insertAppointmentSchema.parse(req.body);
      const appointment = await storage.createAppointment({
        ...appointmentData,
        userId: req.session.userId!,
      });
      res.json(appointment);
    } catch (error) {
      res.status(400).json({ error: "Invalid appointment data" });
    }
  });

  app.get("/api/appointments", requireAuth, async (req, res) => {
    const appointments = await storage.getUserAppointments(req.session.userId!);
    res.json(appointments);
  });

  return createServer(app);
}