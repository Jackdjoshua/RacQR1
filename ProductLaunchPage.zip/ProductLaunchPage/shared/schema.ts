import { pgTable, text, serial, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  profilePicture: text("profile_picture"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const rackets = pgTable("rackets", {
  id: serial("id").primaryKey(),
  brand: varchar("brand", { length: 100 }).notNull(),
  model: varchar("model", { length: 100 }).notNull(),
  serialNumber: varchar("serial_number", { length: 100 }).notNull(),
  owner: varchar("owner", { length: 100 }).notNull(),
  stringTension: integer("string_tension"),
  mainStrings: varchar("main_strings", { length: 100 }),
  crossStrings: varchar("cross_strings", { length: 100 }),
  qrCode: text("qr_code").notNull(),
  userId: serial("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users)
  .pick({
    email: true,
    password: true,
    name: true,
    phone: true,
    profilePicture: true,
  })
  .extend({
    email: z.string().email("Invalid email address"),
    password: z.string().min(6, "Password must be at least 6 characters"),
    name: z.string().min(1, "Name is required"),
    phone: z.string().optional(),
    profilePicture: z.string().optional(),
  });

export const insertRacketSchema = createInsertSchema(rackets)
  .pick({
    brand: true,
    model: true,
    serialNumber: true,
    owner: true,
    userId: true,
    stringTension: true,
    mainStrings: true,
    crossStrings: true,
  })
  .extend({
    brand: z.string().min(1, "Brand is required"),
    model: z.string().min(1, "Model is required"),
    serialNumber: z.string().min(1, "Serial number is required"),
    owner: z.string().min(1, "Owner name is required"),
    userId: z.number().int().min(1, "User ID is required"),
    stringTension: z.number().min(30).max(70).optional(),
    mainStrings: z.string().optional(),
    crossStrings: z.string().optional(),
  });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertRacket = z.infer<typeof insertRacketSchema>;
export type Racket = typeof rackets.$inferSelect;

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  racketId: serial("racket_id").references(() => rackets.id),
  notes: text("notes"),
  userId: serial("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAppointmentSchema = createInsertSchema(appointments)
  .pick({
    date: true,
    racketId: true,
    notes: true,
  });

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;